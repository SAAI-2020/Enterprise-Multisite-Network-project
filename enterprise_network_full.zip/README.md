
# Enterprise Multi-Site Network Project (Cisco Packet Tracer)

A complete enterprise-grade HQ + Branch network implementation featuring VLANs, Inter-VLAN routing,
WAN serial connectivity, DHCP, ACL firewalling, ISP simulation, NAT, SSH, Syslog, SNMP, and full documentation.

## Folder Structure
```
/documentation
/configs
/diagram
/packet-tracer
/guides
```

## Features
- VLAN segmentation (HQ + Branch)
- Inter-VLAN Routing (Router-on-a-stick)
- WAN Serial link (HQ ↔ Branch)
- DHCP for all VLANs
- NAT Overload for Internet access
- ACLs simulating firewall rules
- SSH Router Management
- Syslog Logging
- SNMP Monitoring
- Port Security on Switches
- Professional Documentation + Diagram

See documentation/full-documentation.md for complete details.
