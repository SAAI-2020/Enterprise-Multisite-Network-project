
# Full Enterprise Network Documentation

## 1. Overview
This document covers every component of the HQ + Branch enterprise network.

## 2. VLAN Table
HQ:
- VLAN 10 HR
- VLAN 20 IT
- VLAN 30 ADMIN

Branch:
- VLAN 40 Sales
- VLAN 50 Support

## 3. Services Implemented
- DHCP for all VLANs
- Static Routing HQ ↔ Branch
- NAT Overload on HQ router
- ACL segmentation
- SNMP v2c monitoring
- SSH secured access
- Syslog (local logging)
- Port security on switches
- Spanning Tree enabled

## 4. Configs
All device configs located in /configs.

## 5. Diagram
Diagram PNG provided under /diagram.

## 6. Packet Tracer
Place your .pkt file inside /packet-tracer.

